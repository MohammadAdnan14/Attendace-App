// Custom vector SVG assets for UI controls, status indicators, and badges
const ICONS = {
  reset: '<svg class="reset-svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path></svg>',
  warning: '<svg class="toast-svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
  check: '<svg class="status-svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
  info: '<svg class="status-svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'
};

function calculateInsights() {
  console.log('Starting attendance calculation...');
  
  // Look for the attendance table - it should have columns for Code, Course Name, Attendance Count, and Percentage
  const tables = document.querySelectorAll('table');
  let table = null;
  
  // Find the table that has the attendance data
  tables.forEach((t, index) => {
    const headers = t.querySelectorAll('th');
    const headerTexts = Array.from(headers).map(h => h.innerText.trim());
    console.log(`Table ${index} headers:`, headerTexts);
    
    if (headerTexts.includes('Code') && 
        headerTexts.includes('Course Name') && 
        headerTexts.includes('Attendance Count') && 
        headerTexts.includes('Percentage')) {
      table = t;
      console.log('Found attendance table!');
    }
  });

  if (!table) {
    console.log('Attendance table not found');
    displayPopup([]);
    return;
  }

  // Log the entire table HTML for debugging
  console.log('Table HTML:', table.outerHTML);

  const rows = table.querySelectorAll('tbody tr');
  console.log(`Found ${rows.length} rows to process`);
  
  const threshold = 60;
  const results = [];

  rows.forEach((row, index) => {
    // Skip the last row which contains totals
    if (index === rows.length - 1) {
      console.log('Skipping total row');
      return;
    }

    // Log the entire row HTML for debugging
    console.log(`Row ${index} HTML:`, row.outerHTML);

    const cols = row.querySelectorAll("td");
    console.log(`Row ${index} has ${cols.length} columns`);
    
    if (cols.length < 4) {
      console.log(`Skipping row ${index}: insufficient columns`);
      return;
    }

    // Log each column's content
    cols.forEach((col, colIndex) => {
      console.log(`Column ${colIndex} content:`, col.innerText.trim());
    });

    const subject = cols[1].innerText.trim();
    const attendanceLink = cols[2].querySelector('a');
    
    if (!attendanceLink) {
      console.log(`Skipping row ${index}: no attendance link found`);
      return;
    }

    const attendanceText = attendanceLink.innerText.trim();
    console.log(`Attendance text for ${subject}:`, attendanceText);

    const [attended, total] = attendanceText.split('/').map(num => parseInt(num.trim()));
    const percentage = parseFloat(cols[3].innerText.trim());

    console.log('Row data:', { subject, attended, total, percentage });

    if (isNaN(attended) || isNaN(total) || total === 0) {
      console.log(`Skipping row ${index}: invalid numbers`);
      return;
    }

    let belowThreshold = false;
    let extraClasses = 0;
    let directAttendance = 0;
    let bunkable = 0;
    let message = "";

    if ((attended / total) * 100 < threshold) {
      belowThreshold = true;
      let tempAttended = attended;
      let tempTotal = total;
      
      while ((tempAttended / tempTotal) * 100 < threshold) {
        tempAttended += 1;
        tempTotal += 1;
        extraClasses += 1;
      }
      directAttendance = Math.ceil((threshold / 100) * total) - attended;
    } else {
      let tempTotal = total;
      while ((attended / tempTotal) * 100 >= threshold) {
        tempTotal += 1;
        bunkable += 1;
      }
      bunkable -= 1; // The last increment takes it below threshold
      message = bunkable === 0 
        ? "Right on edge"
        : "You can skip " + bunkable + " classes";
    }

    results.push({ 
      subject, 
      percentage: percentage.toFixed(2), 
      message,
      attended,
      total,
      belowThreshold,
      extraClasses,
      directAttendance,
      bunkable
    });
  });

  console.log('Final results:', results);
  displayPopup(results);
}

function calculateOverallAttendance(data) {
  const total = data.reduce((sum, course) => sum + course.total, 0);
  const attended = data.reduce((sum, course) => sum + course.attended, 0);
  const percentage = (attended / total) * 100;
  const overallThreshold = 75; // Fixed threshold for overall attendance
  
  let belowThreshold = false;
  let requiredClasses = 0;
  let directAttendance = 0;
  let skippableClasses = 0;
  let message = "";

  if (percentage < overallThreshold) {
    belowThreshold = true;
    let currentAttended = attended;
    let currentTotal = total;
    
    while ((currentAttended / currentTotal) * 100 < overallThreshold) {
      currentAttended++;
      currentTotal++;
      requiredClasses++;
    }
    directAttendance = Math.ceil((overallThreshold / 100) * total) - attended;
  } else {
    skippableClasses = Math.floor((attended / 0.75) - total);
    message = skippableClasses === 0
      ? "Right on edge"
      : "You can skip " + skippableClasses + " classes";
  }
  
  return {
    percentage: percentage.toFixed(2),
    belowThreshold,
    requiredClasses,
    directAttendance,
    skippableClasses,
    message,
    total,
    attended
  };
}

// Simulation state: maps subject name -> { attendedDelta: number, totalDelta: number }
window.attendanceSimulations = window.attendanceSimulations || {};
window.whatIfModeActive = window.whatIfModeActive || false;
window.frozenSubjectOrder = window.frozenSubjectOrder || null;
window.attendancePopupPosition = window.attendancePopupPosition || null;

function displayPopup(data) {
  // Capture current scroll positions and position before removing existing popup
  let bodyWrapperScroll = 0;
  let subjectListScroll = 0;
  const existingPopup = document.getElementById('attendance-popup');
  if (existingPopup) {
    const existingWrapper = existingPopup.querySelector('.popup-body-wrapper');
    if (existingWrapper) bodyWrapperScroll = existingWrapper.scrollTop;
    const existingList = existingPopup.querySelector('.subject-list');
    if (existingList) subjectListScroll = existingList.scrollTop;
    if (existingPopup.style.left && existingPopup.style.top) {
      window.attendancePopupPosition = {
        left: existingPopup.style.left,
        top: existingPopup.style.top
      };
    }
    existingPopup.remove();
  }

  const popup = document.createElement("div");
  popup.id = "attendance-popup";

  // Restore position (memory or persistent Storage)
  if (window.attendancePopupPosition) {
    popup.style.left = window.attendancePopupPosition.left;
    popup.style.top = window.attendancePopupPosition.top;
    popup.style.right = 'auto';
    popup.style.bottom = 'auto';
  } else {
    Storage.get('attendance-popup-pos', null, function(savedPos) {
      if (savedPos) {
        try {
          const parsed = typeof savedPos === 'string' ? JSON.parse(savedPos) : savedPos;
          if (parsed && parsed.left && parsed.top) {
            window.attendancePopupPosition = parsed;
            popup.style.left = parsed.left;
            popup.style.top = parsed.top;
            popup.style.right = 'auto';
            popup.style.bottom = 'auto';
          }
        } catch (e) {}
      }
    });
  }

  // Restore states using Storage helper (or initial state)
  Storage.get('attendance-theme', 'light', function(savedTheme) {
    if (savedTheme === 'dark') {
      popup.classList.add('dark-theme');
    }
  });

  Storage.get('attendance-collapsed', 'false', function(savedCollapsed) {
    if (savedCollapsed === 'true' || savedCollapsed === true) {
      popup.classList.add('collapsed');
    }
    const collapseBtn = popup.querySelector('#collapse-toggle');
    if (collapseBtn) {
      collapseBtn.textContent = popup.classList.contains('collapsed') ? "➕" : "➖";
      collapseBtn.title = popup.classList.contains('collapsed') ? "Expand" : "Minimize";
    }
  });

  if (window.whatIfModeActive) {
    popup.classList.add('whatif-active');
  }

  if (data.length === 0) {
    popup.innerHTML = 
      "<div class='popup-header'>" +
        "<div class='header-left'>" +
          "<span class='header-icon'>📊</span>" +
          "<h3>RBU Attendance Planner</h3>" +
        "</div>" +
        "<div class='header-controls'>" +
          "<button id='whatif-toggle' class='control-btn" + (window.whatIfModeActive ? " active" : "") + "' title='Toggle What-If Simulation'>🔮</button>" +
          "<button id='theme-toggle' class='control-btn' title='Toggle Theme'>🌓</button>" +
          "<button id='collapse-toggle' class='control-btn' title='Minimize'>➖</button>" +
        "</div>" +
      "</div>" +
      "<div class='popup-body-wrapper'>" +
        "<div class='error-view'>" +
          "<p>No attendance data found. Please make sure:</p>" +
          "<ul>" +
            "<li>You're on the correct page</li>" +
            "<li>The attendance table is visible</li>" +
            "<li>You're logged in to the portal</li>" +
          "</ul>" +
        "</div>" +
      "</div>";
  } else {
    // Apply simulation deltas to data
    let hasActiveSimulations = false;
    const simulatedData = data.map(d => {
      const sim = window.attendanceSimulations[d.subject] || { attendedDelta: 0, totalDelta: 0 };
      if (sim.attendedDelta !== 0 || sim.totalDelta !== 0) {
        hasActiveSimulations = true;
      }
      
      const effectiveAttended = Math.max(0, d.attended + sim.attendedDelta);
      const effectiveTotal = Math.max(1, d.total + sim.totalDelta);
      const effectivePercentage = (effectiveAttended / effectiveTotal) * 100;
      const threshold = 60;

      let belowThreshold = false;
      let extraClasses = 0;
      let directAttendance = 0;
      let bunkable = 0;
      let message = "";

      if (effectivePercentage < threshold) {
        belowThreshold = true;
        let tempAttended = effectiveAttended;
        let tempTotal = effectiveTotal;
        while ((tempAttended / tempTotal) * 100 < threshold) {
          tempAttended += 1;
          tempTotal += 1;
          extraClasses += 1;
        }
        directAttendance = Math.ceil((threshold / 100) * effectiveTotal) - effectiveAttended;
      } else {
        let tempTotal = effectiveTotal;
        while ((effectiveAttended / tempTotal) * 100 >= threshold) {
          tempTotal += 1;
          bunkable += 1;
        }
        bunkable -= 1;
        message = bunkable === 0 
          ? "Right on edge"
          : "You can skip " + bunkable + " classes";
      }

      return {
        ...d,
        effectiveAttended,
        effectiveTotal,
        effectivePercentage: effectivePercentage.toFixed(2),
        belowThreshold,
        extraClasses,
        directAttendance,
        bunkable,
        message,
        attendedDelta: sim.attendedDelta,
        totalDelta: sim.totalDelta
      };
    });

    const overall = calculateOverallAttendance(simulatedData.map(s => ({
      ...s,
      attended: s.effectiveAttended,
      total: s.effectiveTotal
    })));
    
    // Freeze subject order during simulation so cards don't jump around under the user's cursor
    if (!hasActiveSimulations && !window.whatIfModeActive) {
      // Normal mode: sort critical courses to the top so students spot them instantly
      simulatedData.sort((a, b) => {
        if (a.belowThreshold && !b.belowThreshold) return -1;
        if (!a.belowThreshold && b.belowThreshold) return 1;
        return parseFloat(a.effectivePercentage) - parseFloat(b.effectivePercentage);
      });
      // Save this baseline order
      window.frozenSubjectOrder = simulatedData.map(s => s.subject);
    } else if (window.frozenSubjectOrder && window.frozenSubjectOrder.length > 0) {
      // Simulation active: strictly preserve the frozen baseline order
      simulatedData.sort((a, b) => {
        const indexA = window.frozenSubjectOrder.indexOf(a.subject);
        const indexB = window.frozenSubjectOrder.indexOf(b.subject);
        if (indexA !== -1 && indexB !== -1) return indexA - indexB;
        return 0;
      });
    } else {
      // Fallback if no frozen order saved yet
      simulatedData.sort((a, b) => {
        if (a.belowThreshold && !b.belowThreshold) return -1;
        if (!a.belowThreshold && b.belowThreshold) return 1;
        return parseFloat(a.effectivePercentage) - parseFloat(b.effectivePercentage);
      });
      window.frozenSubjectOrder = simulatedData.map(s => s.subject);
    }

    let overallRecommendations = "";
    if (overall.belowThreshold) {
      const attendTitle = "Attend " + overall.requiredClasses + " classes to reach 75%+ attendance";
      const leaveTitle = "Claim " + overall.directAttendance + " leaves to reach 75%+ attendance";
      overallRecommendations = 
        "<div class='overall-recommendations'>" +
          "<div class='rec-badge attend' title='" + attendTitle + "'>" +
            "<span class='badge-label'>Attend:</span>" +
            "<span class='badge-val'>+" + overall.requiredClasses + " classes</span>" +
          "</div>" +
          "<div class='rec-badge direct' title='" + leaveTitle + "'>" +
            "<span class='badge-label'>Claim Leave:</span>" +
            "<span class='badge-val'>+" + overall.directAttendance + " present</span>" +
          "</div>" +
        "</div>";
    } else {
      const isEdge = overall.skippableClasses === 0;
      overallRecommendations = "<p class='overall-message safe" + (isEdge ? " edge" : "") + "'>" + (isEdge ? ICONS.info : ICONS.check) + "<span>" + overall.message + " to stay above 75%</span></p>";
    }

    let html = 
      "<div class='popup-header'>" +
        "<div class='header-left'>" +
          "<span class='header-icon'>📊</span>" +
          "<h3>RBU Attendance Planner</h3>" +
        "</div>" +
        "<div class='header-controls'>" +
          "<button id='whatif-toggle' class='control-btn" + (window.whatIfModeActive ? " active" : "") + "' title='Toggle What-If Simulation'>🔮</button>" +
          "<button id='theme-toggle' class='control-btn' title='Toggle Theme'>🌓</button>" +
          "<button id='collapse-toggle' class='control-btn' title='Minimize'>➖</button>" +
        "</div>" +
      "</div>" +
      "<div class='popup-body-wrapper'>" +
        "<div class='attendance-summary" + (hasActiveSimulations ? " sim-highlight" : "") + "'>" +
          "<div class='summary-top'>" +
            "<span class='summary-label'>Overall Attendance " + (hasActiveSimulations ? "<span class='sim-tag'>(SIMULATED)</span>" : "") + "</span>" +
            "<span class='summary-value " + (overall.belowThreshold ? 'low-attendance' : '') + "'>" + overall.percentage + "%</span>" +
          "</div>" +
          "<div class='progress-bar-container'>" +
            "<div class='progress-bar-fill' style='width: " + Math.min(100, Math.max(0, overall.percentage)) + "%'></div>" +
          "</div>" +
          overallRecommendations +
          (hasActiveSimulations ? "<div class='reset-sim-wrapper'><button id='reset-sim-btn' class='reset-sim-btn'>" + ICONS.reset + "<span>Reset Simulation</span></button></div>" : "") +
        "</div>" +
        "<ul class='subject-list'>";
    
    simulatedData.forEach(d => {
      let recHtml = "";
      if (d.belowThreshold) {
        const subAttendTitle = "Attend " + d.extraClasses + " classes to reach 60%+ attendance";
        const subLeaveTitle = "Claim " + d.directAttendance + " leaves to reach 60%+ attendance";
        recHtml = 
          "<div class='recommendation-badges'>" +
            "<span class='rec-badge-mini attend' title='" + subAttendTitle + "'>Attend: +" + d.extraClasses + "</span>" +
            "<span class='rec-badge-mini direct' title='" + subLeaveTitle + "'>Leave: +" + d.directAttendance + "</span>" +
          "</div>";
      } else {
        const isEdge = d.bunkable === 0;
        recHtml = "<span class='safe-message" + (isEdge ? " edge" : "") + "'>" + (isEdge ? ICONS.info : ICONS.check) + "<span>" + d.message + "</span></span>";
      }

      const deltaText = d.totalDelta > 0 
        ? `<span class='delta-tag'>(${d.attendedDelta >= 0 ? '+' + d.attendedDelta : d.attendedDelta}/${d.totalDelta >= 0 ? '+' + d.totalDelta : d.totalDelta})</span>`
        : "";

      const hasSubjectSimulation = (d.attendedDelta !== 0 || d.totalDelta !== 0);
      const isFullAttendance = (d.effectiveAttended >= d.effectiveTotal);

      html += 
        "<li class='subject-card " + (d.belowThreshold ? 'warning-card' : '') + "'>" +
          "<div class='subject-header'>" +
            "<strong class='subject-title'>" + d.subject + "</strong>" +
            "<span class='subject-percentage " + (d.belowThreshold ? "low-attendance" : "") + "'>" + d.effectivePercentage + "%</span>" +
          "</div>" +
          "<div class='subject-body'>" +
            "<span class='count'>(" + d.effectiveAttended + "/" + d.effectiveTotal + " classes) " + deltaText + "</span>" +
            recHtml +
          "</div>" +
          (window.whatIfModeActive ? 
            "<div class='whatif-controls'>" +
              "<span class='whatif-label'>Simulate:</span>" +
              "<button class='sim-btn attend-btn' data-subject='" + encodeURIComponent(d.subject) + "' title='Simulate Attending 1 Class (+1 Attended, +1 Total)'>+ Attend</button>" +
              "<button class='sim-btn claim-btn" + (isFullAttendance ? " disabled" : "") + "' data-subject='" + encodeURIComponent(d.subject) + "' data-is-full='" + isFullAttendance + "' title='" + (isFullAttendance ? "Attendance is already 100%. Cannot claim medical leave beyond total conducted classes." : "Simulate Claiming Medical Leave (+1 Attended, +0 Total)") + "'>+ Claim</button>" +
              "<button class='sim-btn miss-btn' data-subject='" + encodeURIComponent(d.subject) + "' title='Simulate Missing 1 Class (+0 Attended, +1 Total)'>- Miss</button>" +
              (hasSubjectSimulation ? "<button class='sim-btn reset-subject-btn' data-subject='" + encodeURIComponent(d.subject) + "' title='Reset simulation for this subject'>" + ICONS.reset + "<span>Reset</span></button>" : "") +
            "</div>" : "") +
        "</li>";
    });

    const qrUrl = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
      ? chrome.runtime.getURL('qr.png')
      : (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getURL)
        ? browser.runtime.getURL('qr.png')
        : 'qr.png';

    html += "</ul>" +
      "<div class='popup-footer'>" +
        "<button id='coffee-btn' class='coffee-btn' type='button'>" +
          "<svg class='coffee-icon' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M18 8h1a4 4 0 0 1 0 8h-1'></path><path d='M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z'></path><line x1='6' y1='1' x2='6' y2='4'></line><line x1='10' y1='1' x2='10' y2='4'></line><line x1='14' y1='1' x2='14' y2='4'></line></svg>" +
          "<span>Buy me a Cold Brew</span>" +
          "<svg class='chevron-icon' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'></polyline></svg>" +
        "</button>" +
        "<div id='donation-drawer' class='donation-drawer hidden'>" +
          "<p class='donation-pitch'>If this tool helped your attendance, buy me a cold brew to keep it running!</p>" +
          "<div class='qr-container'>" +
            "<img src='" + qrUrl + "' alt='UPI QR Code' class='upi-qr-image' />" +
            "<span class='qr-scan-hint'>Scan to pay via any UPI App (GPay / PhonePe / Paytm)</span>" +
          "</div>" +
        "</div>" +
      "</div>" +
    "</div>";

    popup.innerHTML = html;
  }

  document.body.appendChild(popup);

  // Restore scroll positions seamlessly
  const newWrapper = popup.querySelector('.popup-body-wrapper');
  if (newWrapper && bodyWrapperScroll > 0) newWrapper.scrollTop = bodyWrapperScroll;
  const newList = popup.querySelector('.subject-list');
  if (newList && subjectListScroll > 0) newList.scrollTop = subjectListScroll;

  // Setup event listeners after appending to DOM
  const whatIfToggle = document.getElementById('whatif-toggle');
  if (whatIfToggle) {
    whatIfToggle.addEventListener('click', () => {
      window.whatIfModeActive = !window.whatIfModeActive;
      displayPopup(data);
    });
  }

  const resetSimBtn = document.getElementById('reset-sim-btn');
  if (resetSimBtn) {
    resetSimBtn.addEventListener('click', () => {
      window.attendanceSimulations = {};
      window.frozenSubjectOrder = null;
      displayPopup(data);
    });
  }

  const attendBtns = popup.querySelectorAll('.sim-btn.attend-btn');
  attendBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const subject = decodeURIComponent(btn.getAttribute('data-subject'));
      if (!window.attendanceSimulations[subject]) {
        window.attendanceSimulations[subject] = { attendedDelta: 0, totalDelta: 0 };
      }
      window.attendanceSimulations[subject].attendedDelta += 1;
      window.attendanceSimulations[subject].totalDelta += 1;
      displayPopup(data);
    });
  });

  const claimBtns = popup.querySelectorAll('.sim-btn.claim-btn');
  claimBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const isFull = btn.getAttribute('data-is-full') === 'true';
      if (isFull) {
        showToast("Attendance is already 100%! You cannot claim medical leave beyond conducted classes.");
        return;
      }
      const subject = decodeURIComponent(btn.getAttribute('data-subject'));
      if (!window.attendanceSimulations[subject]) {
        window.attendanceSimulations[subject] = { attendedDelta: 0, totalDelta: 0 };
      }
      window.attendanceSimulations[subject].attendedDelta += 1; // Only numerator increases
      displayPopup(data);
    });
  });

  const missBtns = popup.querySelectorAll('.sim-btn.miss-btn');
  missBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const subject = decodeURIComponent(btn.getAttribute('data-subject'));
      if (!window.attendanceSimulations[subject]) {
        window.attendanceSimulations[subject] = { attendedDelta: 0, totalDelta: 0 };
      }
      window.attendanceSimulations[subject].totalDelta += 1;
      displayPopup(data);
    });
  });

  const resetSubjectBtns = popup.querySelectorAll('.sim-btn.reset-subject-btn');
  resetSubjectBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const subject = decodeURIComponent(btn.getAttribute('data-subject'));
      delete window.attendanceSimulations[subject];
      displayPopup(data);
    });
  });

  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      popup.classList.toggle('dark-theme');
      const currentTheme = popup.classList.contains('dark-theme') ? 'dark' : 'light';
      Storage.set('attendance-theme', currentTheme);
    });
  }

  const collapseToggle = document.getElementById('collapse-toggle');
  if (collapseToggle) {
    collapseToggle.textContent = popup.classList.contains('collapsed') ? "➕" : "➖";
    collapseToggle.title = popup.classList.contains('collapsed') ? "Expand" : "Minimize";
    collapseToggle.addEventListener('click', () => {
      popup.classList.toggle('collapsed');
      const isCollapsed = popup.classList.contains('collapsed');
      Storage.set('attendance-collapsed', isCollapsed ? 'true' : 'false');
      collapseToggle.textContent = isCollapsed ? "➕" : "➖";
      collapseToggle.title = isCollapsed ? "Expand" : "Minimize";
    });
  }

  const coffeeBtn = document.getElementById('coffee-btn');
  const donationDrawer = document.getElementById('donation-drawer');
  if (coffeeBtn && donationDrawer) {
    coffeeBtn.addEventListener('click', () => {
      donationDrawer.classList.toggle('hidden');
      coffeeBtn.classList.toggle('active');
    });
  }

  const copyButtons = popup.querySelectorAll('.copy-btn');
  copyButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const address = btn.getAttribute('data-address');
      navigator.clipboard.writeText(address).then(() => {
        const originalText = btn.textContent;
        btn.textContent = "Copied!";
        btn.classList.add('copied');
        setTimeout(() => {
          btn.textContent = originalText;
          btn.classList.remove('copied');
        }, 1500);
      }).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    });
  });

  // Draggable window implementation
  const header = popup.querySelector('.popup-header');
  if (header) {
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let initialLeft = 0;
    let initialTop = 0;

    const startDrag = (clientX, clientY) => {
      isDragging = true;
      startX = clientX;
      startY = clientY;
      const rect = popup.getBoundingClientRect();
      initialLeft = rect.left;
      initialTop = rect.top;
      popup.style.right = 'auto';
      popup.style.bottom = 'auto';
      popup.style.left = initialLeft + 'px';
      popup.style.top = initialTop + 'px';
      popup.classList.add('is-dragging');
    };

    const moveDrag = (clientX, clientY) => {
      if (!isDragging) return;
      const dx = clientX - startX;
      const dy = clientY - startY;
      const pad = 10;
      const maxLeft = Math.max(pad, window.innerWidth - popup.offsetWidth - pad);
      const maxTop = Math.max(pad, window.innerHeight - 50);

      const newLeft = Math.min(Math.max(pad, initialLeft + dx), maxLeft);
      const newTop = Math.min(Math.max(pad, initialTop + dy), maxTop);

      popup.style.left = newLeft + 'px';
      popup.style.top = newTop + 'px';
    };

    const stopDrag = () => {
      if (!isDragging) return;
      isDragging = false;
      popup.classList.remove('is-dragging');
      window.attendancePopupPosition = {
        left: popup.style.left,
        top: popup.style.top
      };
      Storage.set('attendance-popup-pos', JSON.stringify(window.attendancePopupPosition));
    };

    // Mouse drag handlers
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.header-controls') || e.target.closest('button')) return;
      if (e.button !== 0) return;
      e.preventDefault();
      startDrag(e.clientX, e.clientY);

      const onMouseMove = (ev) => {
        ev.preventDefault();
        moveDrag(ev.clientX, ev.clientY);
      };

      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        stopDrag();
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });

    // Touch drag handlers (for touch screens/tablets)
    header.addEventListener('touchstart', (e) => {
      if (e.target.closest('.header-controls') || e.target.closest('button')) return;
      if (e.touches.length !== 1) return;
      const touch = e.touches[0];
      startDrag(touch.clientX, touch.clientY);

      const onTouchMove = (ev) => {
        if (ev.touches.length !== 1) return;
        ev.preventDefault();
        moveDrag(ev.touches[0].clientX, ev.touches[0].clientY);
      };

      const onTouchEnd = () => {
        document.removeEventListener('touchmove', onTouchMove);
        document.removeEventListener('touchend', onTouchEnd);
        stopDrag();
      };

      document.addEventListener('touchmove', onTouchMove, { passive: false });
      document.addEventListener('touchend', onTouchEnd);
    }, { passive: true });
  }
}

// Clamp popup position on window resize to keep it on-screen
window.addEventListener('resize', () => {
  const p = document.getElementById('attendance-popup');
  if (p && p.style.left) {
    const rect = p.getBoundingClientRect();
    const pad = 10;
    if (rect.right > window.innerWidth) {
      p.style.left = Math.max(pad, window.innerWidth - p.offsetWidth - pad) + 'px';
      if (window.attendancePopupPosition) window.attendancePopupPosition.left = p.style.left;
    }
    if (rect.bottom > window.innerHeight) {
      p.style.top = Math.max(pad, window.innerHeight - p.offsetHeight - pad) + 'px';
      if (window.attendancePopupPosition) window.attendancePopupPosition.top = p.style.top;
    }
  }
});

// Cross-browser storage helper with fallback to localStorage
const Storage = {
  get: function(key, defaultValue, callback) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([key], function(result) {
        callback(result[key] !== undefined ? result[key] : defaultValue);
      });
    } else {
      const val = localStorage.getItem(key);
      callback(val !== null ? val : defaultValue);
    }
  },
  set: function(key, value) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      const obj = {};
      obj[key] = value;
      chrome.storage.local.set(obj);
    } else {
      localStorage.setItem(key, value);
    }
  }
};

function showToast(message) {
  let toast = document.getElementById('attendance-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'attendance-toast';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span class="toast-content">${ICONS.warning}<span>${message}</span></span>`;
  toast.classList.add('show');
  if (window.toastTimeout) clearTimeout(window.toastTimeout);
  window.toastTimeout = setTimeout(() => {
    toast.classList.remove('show');
  }, 2500);
}

// Wait for the page to be fully loaded with debounced observer
function initializeExtension() {
  if (window.attendanceTimeout) {
    clearTimeout(window.attendanceTimeout);
  }
  
  window.attendanceTimeout = setTimeout(() => {
    calculateInsights();
  }, 500);
  
  const observer = new MutationObserver((mutations) => {
    let shouldRecalculate = false;
    for (const mutation of mutations) {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        const hasTable = Array.from(mutation.addedNodes).some(node => 
          node.nodeType === 1 && (node.matches('table') || node.querySelector('table'))
        );
        if (hasTable) {
          shouldRecalculate = true;
          break;
        }
      }
    }
    if (shouldRecalculate) {
      if (window.attendanceDebounceTimeout) {
        clearTimeout(window.attendanceDebounceTimeout);
      }
      window.attendanceDebounceTimeout = setTimeout(() => {
        calculateInsights();
      }, 300);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeExtension);
} else {
  initializeExtension();
}